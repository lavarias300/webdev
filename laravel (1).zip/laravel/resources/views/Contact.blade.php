<!DOCTYPE html>
<html>
<head>
	<title></title>

	<style type="text/css">
		body{
	
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(images/Home.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
	background-attachment: fixed;
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	font-family: Century Gothic;
}

ul{
	list-style: none;
	font-weight: bold;	

}

ul li{
	margin-left: 23px;
	display: inline-block; 
	font-family: Century Gothic;
}
ul li a{
	text-decoration: none;
	color: #fff;
	padding: 8px 30px;
	border: 1px solid #fff;
	}

.contact{
	position: relative;
	padding: 20px 100px;
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column; 
}
.contact .content{
	max-width: 700px;
	text-align: center;
}
.contact .content h1{
	font-size: 40px;
	color: #fff;
	text-align: center;
	margin-top: 0;
	color: #00bcd4;

}


.contact .content p{
	color: #fff;
	font-size: 16px;
	font-weight: bold;
}
.container{
	width: 100%;
	display: flex;
	justify-content: center;
	align-items: center;
	margin-top: 0;
}

.container .contactInfo{
	width: 50%;
	display: flex;
	flex-direction: column;
}
.container .contactInfo .box{
	position: relative;
	padding: 3px 0;
	display: flex;

}
.container .contactInfo .box .text{
	display: flex;
	margin-left: 20px;
	font-size: 16px;
	flex-direction: column;
	font-weight: bold;
	color: #fff;
}
.container .contactInfo .box .text h2{
	font-weight: 500px;
	color: #00bcd4;
}
.contactForm{
	width: 35%;
	padding: 35px;
	background: #000;
}
.contactForm h3{
	font-size: 30px;
	color: #00bcd4;
}
.contactForm .inputBox{
	position: relative;
	width: 100%;
	margin-top: 10px;	
	color: #fff;
}
.contactForm .inputBox input{
	width: 100%;
	padding: 5px 0;
	font-size: 15px;
	margin: 10px 0;
	border: none;
	border-bottom: 2px solid #00bcd4;
	resize: none;
}

.contactForm .inputBox span{
	position: absolute;
	left: 0;
	padding: 5px 0;
	font-size: 15px;
	margin: 10px 0;
	color: black;
	pointer-events: none;
	transition: 0.5s;
	color: #666;
}
.contactForm .inputBox input[type="submit"]{
	width: 100px;
	background: #00bcd4;
	color: #fff;
	border: none;
	padding: 10px;
	font-size: 15px;
	font-weight: bold;
}
footer{
	text-align: center;
	font-weight: bold;
}
</style>
</head>
<body>
	<center>

	<ul>
		<li><a href="Homepage">Home</a></li>
		<li><a href="About">About</a></li>
		<li><a href="Contact">Contact</a></li>

	</ul>
</center>
	<section class="contact">
		<div class="content">
		<h1>Contact Us</h1>	
		<p>We're here to help and answer any question your might have. We look forward to hearing from you.</p>
		</div>

		<div class="container">
		<div class="contactInfo">
			<div class="box">
				<div class="text">
					<h2>Address</h2>
					<p>Subusub Rosario La Union <br> 2506 </p>
				</div>
			</div>

			<div class="box">
				<div class="text">
					<h2>Phone</h2>
					<p>+639468506146</p>
		</div>
		</div>

		<div class="box">
				<div class="text">
					<h2>Email</h2>
					<p>villafuertejudy058@gmail.com</p>

				</div>
			</div>
		</div>
		<div class="contactForm">
			<form>
				
				<h3>Send Message</h3>
				<div class="inputBox">
					<input type="text">
					<span>Full name</span>

				</div>

				<div class="inputBox">
					<input type="text">
					<span>Email</span>
				</div>

				<div class="inputBox">
					<textarea></textarea>
					<span>Type your Message....</span>
				</div>

				<div class="inputBox">
					<input type="submit" value="Send">
				</div>
			</form>

		</div>
	</div>
	</section>
	<hr>
<footer>@WEBDEV</footer>
</body>
</html>