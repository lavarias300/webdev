<!DOCTYPE html>
<html>
<head>
	<title></title>

	<style type="text/css">

body{
	
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(images/Home.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
	background-attachment: fixed;
}

ul{
	list-style: none;
	font-weight: bold;
}

ul li{
	margin-left: 23px;
	display: inline-block; 
	font-family: Century Gothic;
}
ul li a{
	text-decoration: none;
	color: #fff;
	padding: 8px 30px;
	border: 1px solid #fff;


}
.title{
	font-family: Century Gothic;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%,-50%);

}
.title h1{
	color: #fff;
	font-size: 70px;
}
.button{
	font-family: Century Gothic;
	position: absolute;
	top: 60%;
	left: 50%;
	transform: translate(-50%,-50%);
}
.btn{
	border: 1px solid #fff;
	padding: 10px 30px;
	color: #fff;
	text-decoration: none;

}
footer{
	text-align: center;
	font-weight: bold;
	margin-top: 43%;
	font-family: Century Gothic;
}
</style>
</head>
<body>
	<center>
	<ul>
		<li><a href="Homepage">Home</a></li>
		<li><a href="About">About</a></li>
		<li><a href="Contact">Contact</a></li>
	</ul>
<div class="title">
	<h1>JUDY VILLAFUERTE</h1>
</div>

<div class="button">
	<a href="#" class="btn">WATCH VIDEO</a>
	<a href="#" class="btn">LEARN MORE</a>

</div>
</center>


<footer><hr>@WEBDEV</footer>

</body>
</html>