<!DOCTYPE html>
<html>
<head>
	<title></title>

	<style type="text/css">
body{
	
	background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(images/Home.jpg);
	background-repeat: no-repeat;
	background-size: cover;
	background-position: center;
	background-attachment: fixed;
	margin: 0;
	padding: 0;
	box-sizing: border-box;
	font-family: Century Gothic;
}


ul{
	margin top: 50px;
	list-style: none;
	float: right;
	margin-right: 5%;
}

ul li{
	margin-left: 23px;
	display: inline-block; 
	font-family: Century Gothic;
}
ul li a{
	text-decoration: none;
	color: #fff;
	padding: 7px 25px;
	border: 1px solid #fff;
	}
img {
	height: 40%;
	position: absolute;
	text-align: center;
	margin-left: 515px;

}

h1{
	
	margin-left:10%;
	font-family: Century Gothic;
	font-size: 70px;
	color: #00bcd4;

}
h2{
	font-family: 'Poppins', sans-serif;
	text-align: center;
	margin-top: 23%;
	color: #fff;
	padding: 10px;
}
footer{
	text-align: center;
	font-weight: bold;
}
</style>
</head>
<body>

	
	
	<ul>
		<li><a href="Homepage">Home</a></li>
		<li><a href="About">About</a></li>
		<li><a href="Contact">Contact</a></li>

	</ul>

	<h1>M Y &nbsp; P O R T F O L I O </h1>
	<img src="images/Me.png">
<h2> Name: Judy Villafuerte <br> Age: 21 years old <br> Address: La union <br> Course: Bachelor of Science in Information Technology<hr></h2>
<footer>@WEBDEV</footer>

</body>
</html>